<?php

	session_start();
//DONE EDITING
	unset($_SESSION['loggedIn']);
	unset($_SESSION['bid']);
	// session_destroy();

?>
